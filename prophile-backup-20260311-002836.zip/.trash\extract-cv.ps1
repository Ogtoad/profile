$word = $null
$doc = $null
$pdfPath = 'C:\Users\Shadow\Documents\philip_prstojevic_cv.pdf'
$outPath = 'C:\Users\Shadow\Documents\DEV\prophile\.trash\cv-extract.txt'
try {
  $word = New-Object -ComObject Word.Application
  $word.Visible = $false
  $word.DisplayAlerts = 0
  $doc = $word.Documents.Open($pdfPath, $false, $true)
  $doc.SaveAs([ref]$outPath, [ref]2)
  $doc.Close()
  $word.Quit()
  Get-Content -Raw $outPath
} catch {
  if ($doc -ne $null) { $doc.Close() }
  if ($word -ne $null) { $word.Quit() }
  Write-Output ('ERROR: ' + $_.Exception.Message)
}
