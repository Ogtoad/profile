---
title: AI Överblick
subtitle: Hur tekniken fungerar under ytan
description: En djupdykning i det moderna AI-landskapet — protokoll, träning, destillering, multimodalitet, Transformers, LoRA, RAG, diffusionsmodeller och MoE-arkitekturer.
math:
  '\softmax': '\text{softmax}'
  '\Attention': '\text{Attention}'
---

# AI Överblick

För att förstå hur AI kan skräddarsys för specifika behov är det viktigt att greppa de underliggande mekanismerna. Här navigerar vi genom det moderna AI-landskapets viktigaste byggstenar.

## Standardiserade protokoll (MCP & ACP)

När en modell ska göra mer än att bara skriva text behövs ett tydligt sätt att prata med omvärlden. Därför blir **standardiserade agentprotokoll** centrala.

MCP och ACP är översättningslagret som låter AI-agenter använda verktyg, databaser och utvecklingsmiljöer utan att varje integration måste byggas från grunden.

**Varför det spelar roll:**

- samma agent kan kopplas till flera system med lägre integrationskostnad
- säkerhet, loggning och behörigheter kan centraliseras
- verktygsanrop blir spårbara istället för att försvinna som “magisk” modellogik

```mermaid
flowchart LR
    U[Användare] --> A[AI-agent]
    A --> P[MCP / ACP-lager]
    P --> T[Verktyg]
    P --> D[Databaser]
    P --> E[Utvecklingsmiljö]
    T --> R[Verifierbara resultat]
    D --> R
    E --> R
```

I praktiken betyder detta att språkmodellen inte behöver bära all kunskap eller alla funktioner internt. Den blir istället en **resonerande dirigent** som vet när den ska hämta data, starta ett arbetsflöde eller delegera nästa steg.

---

## Modeller, träning och destillering

All modern AI börjar med träning: modellen justerar miljarder parametrar för att minimera skillnaden mellan sin egen gissning och verkligt utfall. Men den färdiga modellen är ofta för tung för produktion.

Träning skapar den stora lärarmodellen. Destillering komprimerar sedan beteendet till en mindre elevmodell som är billigare, snabbare och nästan lika användbar.

### Destillering i praktiken

Vid **knowledge distillation** tränas elevmodellen inte bara på rätt svar, utan också på hur lärarmodellen fördelar sannolikhet över möjliga svar. Det gör att eleven lär sig *mönster i osäkerheten*, inte bara facit.

$$
\mathcal{L}_{\text{distill}} = \alpha\,\mathcal{L}_{\text{task}} + (1-\alpha)\,D_{KL}(p_{\text{teacher}} \parallel p_{\text{student}})
$$

```mermaid
flowchart LR
    A[Stort rådataflöde] --> B[Förträning]
    B --> C[Stor lärarmodell]
    C --> D[Destillering]
    D --> E[Mindre elevmodell]
    E --> F[Snabbare inferens]
    E --> G[Lägre kostnad]
    E --> H[Lättare drift]
```

Detta är särskilt viktigt när AI ska köras i verkliga system där **latens, GPU-kostnad och energiförbrukning** är affärskritiska variabler.

---

## Finjustering och specialisering

En generell grundmodell är sällan tillräcklig för branschspecifika behov. Där kommer **finetuning** in.

Finjustering innebär att modellens sannolikhetsfördelning flyttas mot en domän: juridik, tillverkning, medicin, kundservice eller intern företagsjargong. Resultatet blir inte bara bättre svar — utan bättre **formatdisciplin, terminologi och beslutslogik**.


| Metod | Styrka | Begränsning |
| --- | --- | --- |
| Prompting | Snabbast att testa | Ytlig och känslig för formulering |
| RAG | Ger aktuell och verifierbar kunskap | Ändrar inte modellens grundbeteende |
| Finetuning | Formar modellens stil och beslutsmönster | Kräver data, träning och utvärdering |


Den bästa produktionen kombinerar ofta alla tre: **prompting för styrning**, **RAG för fakta**, och **finetuning för domänbeteende**.

---

## Multimodala modeller

AI arbetar inte längre bara med text. Moderna modeller kan koppla ihop **bild, ljud, video, tabeller och text** i samma arbetsflöde.

Olika datatyper projiceras in i en gemensam latent representationsrymd där relationer mellan modaliteter blir matematiskt jämförbara.

```mermaid
flowchart LR
    I[Bild] --> L[Gemensam latent rymd]
    V[Röst] --> L
    T[Text] --> L
    S[Sensorer / tabeller] --> L
    L --> O[Beslut, analys eller generering]
```

Det är därför en modell kan:

- läsa en skadad faktura som bild och svara i text
- analysera ett kundsamtal i ljudform och sammanfatta risker
- kombinera kameradata och språkinstruktioner i ett industriellt system

Multimodalitet gör AI mycket mer användbar i verkliga miljöer, eftersom verkligheten själv är **multimodal**.

---

## Klassiska Transformers

Transformern är motorn bakom modern text-AI: en arkitektur som kan läsa långa sekvenser och beräkna relationer mellan ord **parallellt** istället för stegvis.

Kärnan i transformer-arkitekturen är **Self-Attention**-mekanismen. Den beräknar relevansen mellan alla tokens parallellt:

$$
\Attention(Q, K, V) = \softmax\left(\frac{QK^T}{\sqrt{d_k}}\right)V
$$

Där:
- $Q$ = Query-matrisen (vad letar vi efter?)
- $K$ = Key-matrisen (vad finns tillgängligt?)
- $V$ = Value-matrisen (vilken information ska vi hämta?)
- $d_k$ = dimensionen av nycklarna (för skalning)

Transformers blev avgörande eftersom de flyttade språkmodeller från sekventiell bearbetning till **massivt parallell beräkning**. Det gav både högre kvalitet och bättre utnyttjande av modern GPU-hårdvara.

Self-Attention löser problemet med **glömska i långa sekvenser** som drabbade äldre RNN/LSTM-arkitekturer.

---

## Diffusionsmodeller

AI är inte tvingad att skriva text ett ord i taget. Diffusionsmodeller börjar med slumpmässigt **brus** och skulpterar fram hela resultatet parallellt.

### Illustration

*Från brus till struktur — diffusionsprocessen skulpterar koherent data ur slumpmässigt brus genom iterativ förfining.*

### Matematik

Diffusionsmodeller för språk (dLLMs) kringgår den autoregressiva flaskhalsen genom att mappa diskreta tokens till en **kontinuerlig inbäddningsrymd**:

$$
p(x_{1:T}) = \int p(z_0) \prod_{t=1}^{T} p(x_t \mid z_{t-1}) \, p(z_t \mid z_{t-1}) \, dz_{0:T}
$$

Konsekvensen är massiv parallellism och dynamisk kontextkorrigering under genereringen — i rätt sammanhang betydligt snabbare än autoregression.

---

## LoRA — Low-Rank Adaptation

Istället för att bygga om hela AI-motorn byter vi ut en **pytteliten del** för att skräddarsy AI extremt snabbt.

LoRA är särskilt viktig när man vill finjustera modeller i produktion utan att bära kostnaden för full parameteruppdatering. I praktiken blir det en **ingenjörsmässig kompromiss** mellan kvalitet, pris och driftsäkerhet.

{math}
:label: lora-equation
W' = W + BA

Där $W$ är den frysta originalmatrisen och $A$, $B$ är mycket mindre matriser. Resultatet:

- **90%+ färre träningsbara parametrar** i många praktiska upplägg
- **avsevärt snabbare finjustering** än full omträning
- **dramatiskt lägre kostnad** för specialisering i produktion

---

## RAG — Retrieval-Augmented Generation

RAG fungerar som ett **open-book exam**: modellen söker i dina privata och aktuella dokument **innan** den svarar.

**Processen:**

1. Användarens fråga konverteras till en **vektor**
2. De mest matematiskt närliggande dokumenten hämtas ur databasen
3. Dokumenten bifogas i språkmodellens **kontextfönster**
4. Modellen genererar ett svar **grundat i verifierbara fakta**

RAG är därför inte bara ett sätt att “söka dokument”, utan en metod för att koppla AI till **organisatoriskt minne**: policies, teknisk dokumentation, projekthistorik, supportärenden och databasutdrag.

$$
\text{svar} = \text{LLM}\Big(\text{fråga} \oplus \underset{d \in \mathcal{D}}{\arg\max}\; \text{sim}(q, d)\Big)
$$

Utan RAG riskerar AI att **hallucinera** — generera övertygande men felaktig information. RAG minimerar detta genom att grunda svaren i återfunnet material.

---

## Mixture of Experts (MoE)

Ett system av specialister där en **"chef"** dirigerar din fråga till de bäst lämpade experterna:

$$
G(x) = \softmax(W_g \cdot x)
$$

Det stora värdet med MoE är att modellen kan bli **mycket större totalt sett** utan att varje enskild token måste aktivera hela nätverket. Man får alltså hög kapacitet utan att kostnaden per svar växer linjärt.


| Egenskap | MoE | Tät Modell |
| --- | --- | --- |
| Aktiva parametrar | ~25% per token | 100% |
| Energiförbrukning | Låg | Hög |
| Skalbarhet | Utmärkt | Begränsad |
| Latens | Låg | Högre |


---

## Multi-Agent System

Överliggande **Multi-Agent system** låter flera oberoende AI-instanser med olika roller samarbeta iterativt:

```mermaid
graph LR
    A[Användare] --> B[Orchestrator]
    B --> C[Research Agent]
    B --> D[Code Agent]
    B --> E[Validator Agent]
    C --> F[Gemensam Kontext]
    D --> F
    E --> F
    F --> G[Slutresultat]
```

Detta blir särskilt kraftfullt när agentlager kombineras med protokoll som MCP/ACP. Då kan en orchestrator inte bara samordna flera modeller, utan också fördela arbete mellan **modeller, verktyg och externa system** i samma flöde.

Se också [Tillämpningar](../tillampningar/index.md), [Computer Vision](../tillampningar/computer-vision.md) och [Djupsökning](../tillampningar/djupsokning.md).
