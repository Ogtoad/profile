---
title: Kontakt
subtitle: Boka konsultation
description: Kontakta mig för AI-konsultation, samarbete eller frågor.
---

# Kontakt

Har du en idé, ett problem eller en process som behöver ses med nya ögon? Jag arbetar med tillämpad AI — från prototyp till produktion.

---

## Kom igång

Det enklaste sättet att inleda en dialog är att skriva kort och konkret:

- **E-post:** shadow@tillämpad.ai
- **LinkedIn:** [linkedin.com](https://linkedin.com)

Det behöver inte vara färdigformulerat. En idé, ett problem eller en halvfärdig frågeställning räcker.

---

## Hur det fungerar

1. **Beskriv ditt behov** — ett kort meddelande räcker för att starta dialogen.
2. **Initial analys** — jag utvärderar problemdomänen och identifierar var AI kan skapa mest värde.
3. **Förslag** — du får ett konkret förslag med scope, tidsram och förväntad effekt.

Varje uppdrag börjar med en analys av det faktiska problemet. Jag säljer inte färdiga paket; jag bygger lösningar som utgår från situationens struktur, begränsningar och möjligheter.
