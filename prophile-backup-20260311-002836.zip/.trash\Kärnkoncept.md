## Kärnkoncept: Hur Tekniken Fungerar Under Ytan

För att förstå hur AI kan skräddarsys för specifika behov är det viktigt att greppa de underliggande mekanismerna.

## Standardiserade Protokoll (MCP & ACP)

- **Enkelt förklarat:** Detta är språket som låter AI-modeller prata med dina befintliga program, databaser eller utvecklingsverktyg.
    
- **Djupdykning:** Model Context Protocol (MCP) och Agent Control Protocol (ACP) fungerar som standardiserade API-bryggor som tillåter agenter att utföra handlingar i externa miljöer på ett säkert och spårbart sätt.
    

## Modeller, Träning och Destillering

- **Enkelt förklarat:** Träning är hur AI:n lär sig, och destillering är hur vi krymper en stor, dyr "hjärna" till en liten, snabb modell som är nästan lika smart.
    
- **Djupdykning:** Vid _Knowledge Distillation_ tränas en mindre elevmodell att minimera avvikelsen mellan dess egen sannolikhetsfördelning och den massiva lärkarmodellens fördelning (logits), vilket drastiskt reducerar behovet av beräkningskraft.
    

## Finetuning (Finjustering)

- **Enkelt förklarat:** Som att skicka en allmänbildad AI på en specialistutbildning för just din bransch.
    
- **Djupdykning:** Modellens faktiska underliggande parametrar uppdateras via _gradient descent_ på ett domänspecifikt dataset, vilket skiftar modellens matematiska sannolikhetsfördelning för att konsekvent producera rätt jargong och format.
    

## Multimodala Modeller (Bild, Röst och Text)

- **Enkelt förklarat:** Dagens modeller kan "se" bilder, generera realistiska röster och skapa helt ny grafik utifrån dina instruktioner.
    
- **Djupdykning:** Neurala nätverk kan bearbeta och projicera olika typer av data in i en gemensam _latent vektor-rymd_, vilket gör att modellen matematiskt förstår relationen mellan olika modaliteter.
    

## Klassiska Transformers

- **Enkelt förklarat:** Motorn bakom text-AI som kan läsa en hel bok och förstå exakt hur varje ord hänger ihop med alla andra ord.
    
- **Djupdykning:** _Self-Attention_-mekanismen beräknar relevansen mellan alla tokens parallellt genom matrisoperationen $\text{Attention}(Q, K, V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V$. Detta löser problemet med glömska i långa sekvenser.
    

## Diffusion-modeller (För Bild, Video, Text och Kod)

- **Enkelt förklarat:** AI är inte tvingad att skriva text eller kod ett ord i taget. Diffusionsmodeller börjar med slumpmässigt "brus" och skulpterar fram hela resultatet parallellt, vare sig det är en bild eller komplex mjukvarukod.
    
- **Djupdykning:** Diffusionsmodeller för språk (dLLMs) kringgår den autoregressiva flaskhalsen genom att mappa diskreta tokens till en kontinuerlig inbäddningsrymd. Under inferens reducerar modellen bruset från hela sekvensen parallellt enligt integralen $p(x_{1:T}) = \int p(z_0) \prod_{t=1}^{T} p(x_t | z_{t-1}) p(z_t | z_{t-1}) dz_{0:T}$. Detta möjliggör massiv parallellism och dynamisk kontextkorrigering under genereringen.
    

## LoRA (Low-Rank Adaptation)

- **Enkelt förklarat:** Istället för att bygga om hela AI-motorn byter vi bara ut en pytteliten specifik del för att skräddarsy AI extremt snabbt och billigt.
    
- **Djupdykning:** LoRA fryser den ursprungliga viktmatrisen $W$ och introducerar två mycket mindre matriser, $A$ och $B$. Den nya vikten beräknas som $W' = W + BA$, vilket reducerar antalet träningsbara parametrar med över 90%.
    

## RAG (Retrieval-Augmented Generation)

- **Enkelt förklarat:** Ger AI:n förmågan att göra en sökning i dina privata, aktuella dokument innan den svarar, som ett "open-book exam".
    
- **Djupdykning:** Användarens fråga konverteras till en vektor. De mest matematiskt närliggande dokumenten hämtas ur databasen och bifogas i språkmodellens kontextfönster. Detta minimerar hallucinationer genom att grunda svaren i verifierbara fakta.
    

## Mixture of Experts (MoE) & Agenter

- **Enkelt förklarat:** Ett system av specialister där en "chef" dirigerar din fråga till de bäst lämpade experterna i systemet för att spara energi och öka precisionen.
    
- **Djupdykning:** Ett routing-nätverk använder en gating-funktion, $G(x) = \text{softmax}(W_g x)$, för att dirigera tokens till relevanta expertnätverk. Överliggande _Multi-Agent system_ låter dessutom flera oberoende AI-instanser med olika roller samarbeta iterativt för att nå överlägsna slutresultat.